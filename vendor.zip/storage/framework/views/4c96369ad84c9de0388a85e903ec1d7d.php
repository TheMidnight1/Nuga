<section class="white-bg pb-2">
      <div class="owl-carousel slider-section owl-theme">
        <div
          class="item"
          style="background-image: url('<?php echo e(asset('image/slide-1.webp')); ?>')"
        >
          <div class="slider-content">
            <p>Nuga Shop</p>
            <h1>Slide 1</h1>
          </div>
        </div>
        <div
          class="item"
          style="background-image: url('<?php echo e(asset('image/slide-2.webp')); ?>')"
        >
          <div class="slider-content">
            <p>Nuga Shop</p>
            <h1>Slide 2</h1>
          </div>
        </div>
        <div
          class="item"
          style="background-image: url('<?php echo e(asset('image/slide-3.webp')); ?>')"
        >
          <div class="slider-content">
            <p>Nuga Shop</p>
            <h1>Slide 3</h1>
          </div>
        </div>
      </div>
    </section><?php /**PATH D:\Laravel pro\We\Nuga\resources\views/home/slider.blade.php ENDPATH**/ ?>