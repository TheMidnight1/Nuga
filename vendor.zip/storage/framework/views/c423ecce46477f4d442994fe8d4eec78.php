 <!-- Extends the base layout -->

 <!-- Sets the title for the page -->
<?php $__env->startSection('title', 'Home - Nuga'); ?>

<?php $__env->startSection('content'); ?> <!-- Content section starts here -->
    
    <!-- ***************************Slider Section*********************** -->
    <?php echo $__env->make('home.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ***************************Slider Section*********************** -->

    <!-- **************************about section*********************** -->

    <?php echo $__env->make('home.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- **************************about section*********************** -->

    <!-- ********************trending section********************* -->
    <?php echo $__env->make('home.trending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ********************trending section********************* -->

    <!-- ********************product by categories********************* -->
    <?php echo $__env->make('home.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ********************product by categories********************* -->

    <!-- ********************testimonials section********************* -->
    <?php echo $__env->make('home.testimonial  ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ********************testimonials section********************* -->

    <!-- ********************blog section********************* -->
    <?php echo $__env->make('home.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('home.slider-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <!-- ********************blog section********************* -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel pro\We\Nuga\resources\views/index.blade.php ENDPATH**/ ?>