<div class="white-bg py-3">
      <div class="section-header" data-aos="fade-up">
        <div class="tagline">Product By Categories</div>
        <div class="title">Making and Crafts</div>
      </div>
      <div class="row justify-content-center cat-section" data-aos="fade-up">
        <div class="item col-12 col-md-2">
          <a href="/product-detail">
          <div class="cat-section-img">
            <img src="https://imgs.search.brave.com/OKyrO7JmxKJ5u0ShHppLAbn_EAqs0tzDoc1YNG7mb0c/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9zYWZl/aW1hZ2VraXQuY29t/L2Fzc2V0cy9pbWFn/ZXMvZ3JlZW4uc3Zn" alt="Hemp" />
          </div>
          <div class="name">Hemp</div>
          </a>
        </div>
        <div class="item col-12 col-md-2">
          <div class="cat-section-img">
            <img src="https://imgs.search.brave.com/OKyrO7JmxKJ5u0ShHppLAbn_EAqs0tzDoc1YNG7mb0c/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9zYWZl/aW1hZ2VraXQuY29t/L2Fzc2V0cy9pbWFn/ZXMvZ3JlZW4uc3Zn" alt="Hemp" />
          </div>
          <div class="name">Hemp</div>
        </div>
        <div class="item col-12 col-md-2">
          <div class="cat-section-img">
            <img src="https://imgs.search.brave.com/OKyrO7JmxKJ5u0ShHppLAbn_EAqs0tzDoc1YNG7mb0c/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9zYWZl/aW1hZ2VraXQuY29t/L2Fzc2V0cy9pbWFn/ZXMvZ3JlZW4uc3Zn" alt="Hemp" />
          </div>
          <div class="name">Hemp</div>
        </div>
        <div class="item col-12 col-md-2">
          <div class="cat-section-img">
            <img src="https://imgs.search.brave.com/OKyrO7JmxKJ5u0ShHppLAbn_EAqs0tzDoc1YNG7mb0c/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9zYWZl/aW1hZ2VraXQuY29t/L2Fzc2V0cy9pbWFn/ZXMvZ3JlZW4uc3Zn" alt="Hemp" />
          </div>
          <div class="name">Hemp</div>
        </div>
      </div>
    </div>